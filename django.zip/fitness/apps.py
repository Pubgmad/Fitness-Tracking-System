from django.apps import AppConfig


class FitnessConfig(AppConfig):
    name = 'fitness'
